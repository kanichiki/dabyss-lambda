const parts = require("./constants/messageParts");

exports.main = async () => {
    return [
        {
            type: "text",
            text: `ゲームを終了します`
        }
    ]
}